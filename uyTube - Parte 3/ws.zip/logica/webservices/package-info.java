@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservices.logica/")
package logica.webservices;
